const add = (a,b)=>{
return a + b;
}
const sub = (a,b)=>{
    return a - b;
    }
    const mul = (a,b)=>{
        return a * b;
        }

module.exports ={ add,sub,mul}


