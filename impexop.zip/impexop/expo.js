const {add, sub, mul} = require('./index');
console.log(add(5,5));
console.log(sub(10,5));
console.log(mul(10,5));

