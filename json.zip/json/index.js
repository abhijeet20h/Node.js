const fs=require('fs');
const obj = {
name : 'abhi',
age : 23,
channel : 'HELLLLLLO',
};

const jsondata = JSON.stringify(obj);
fs.writeFile("Json1.json", jsondata ,(err) => {
    console.log("done");
});
fs.readFile("Json1.json", "utf-8", (err,data)=>{
console.log(data);
const objdata=JSON.parse(data);
console.log(objdata);

});