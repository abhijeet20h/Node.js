const http =require('http');
const fs = require('fs');
const server = http.createServer((req,res) =>{
    if(req.url=='/'){
        res.end('HOME SIDE');
    }
    else if(req.url=='/about'){
        res.end('ABOUT SIDE');

    }
    else if(req.url=='/u'){
        fs.readFile(`${__dirname}/userapi/userapi.json`, 'utf-8',(err, data)=>{
        console.log(data);
        // const objData = JSON.parse(data);
        res.end(data);
    });
}
    else{
        res.writeHead(404,{'contact-type': 'text/html'});
        res.end('<h1>404 error pages. page does not exist</h1>');
    }
});

server.listen(8000 , '127.0.0.1' , () => {
    console.log('listening port 8000');
});