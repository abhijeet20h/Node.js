const http =  require('http');
const server = http.createServer((x, y) => {
  console.log( x.url);
y.end('Hello from otthrt side abhi');

});
server.listen(8000, '127.0.0.1' , () =>{
console.log('listening to port 8000');
});