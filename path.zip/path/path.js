const path = require('path');
console.log(path.dirname('E:/Node-Practice/path/path.js'));
console.log(path.extname('E:/Node-Practice/path/path.js'));
console.log(path.basename('E:/Node-Practice/path/path.js'));