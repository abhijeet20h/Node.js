const chalk = require('chalk');

console.log(chalk.red.underline('Hello world!'));

var validator = require('validator');

const result = validator.isEmail('foo@bar.com');
console.log(result);