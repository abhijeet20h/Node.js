const EventEmitter = require("events");
const event = new EventEmitter();
event.on("myname", ()=>{
    console.log("abhijeet");
});
event.emit("myname");
